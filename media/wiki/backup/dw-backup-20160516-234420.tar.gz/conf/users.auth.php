admin:d7204f06b530649b34021933c2ed938a:DokuWiki Administrator:webmaster@localhost:admin,user
simas:$1$YX7vVUlu$z2gzt6oEDAjG5Xfdg0ig4/:Fabio Simas:fabio.simas@uniriotec.br:coordenadores
hjbortol:$1$He95j6wo$JEfTiCDPXBME.cBgslsoE0:Humberto Bortolossi:hjbortol@gmail.com:coordenadores
leticiarangel:$1$HSNbugCq$NmbnzaXnWesp5CVEkScKh/:Leticia Rangel:leticiagrangel@gmail.com:coordenadores
victor:$1$Qodc9YVo$JbKLzbYksJedYhDLeOOKw/:Victor Giraldo:victor.giraldo@gmail.com:coordenadores
anapaula:$1$hOHnjdyQ$gVMckQrcErX/B2FJZTzfj/:Ana Paula:anaperei@hotmail.com:coordenadores
luizfelipe:$1$w0OXMTkF$bd8mJT3hSFAhp1qYlOnjQ1:Luiz Felipe:lfelipel@terra.com.br:coordenadores
cydara:$1$S2npcP3U$aHRp/28lB3Oy/8HsBkMi3.:Cydara Ripoll:cydara@mat.ufrgs.br:coordenadores
francisco:$1$swrE3NZi$YVFcxSOVNOno37k907Bzi/:Francisco Mattos:francisco.mattos@gmail.com:coordenadores
michel:$1$WiVoqIZM$XItB7VfTvCzgchalZpb3p.:Michel Cambrainha:michel.cambrainha@uniriotec.br:coordenadores
cataldo:$1$YN4efwE7$hf.lLXsO8UW1.9VPoADeF/:Cataldo:jcc.cataldo@gmail.com:coordenadores
srvaz:$1$IANP10Il$6TVLq3Z6F6WbJ9IUqh8qj/:Sergio Vaz:srvaz@impa.br:user
