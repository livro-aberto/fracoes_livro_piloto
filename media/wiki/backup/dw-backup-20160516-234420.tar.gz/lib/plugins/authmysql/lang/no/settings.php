<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Patrick <spill.p@hotmail.com>
 */
$lang['server']                = 'Din MySQL-server';
$lang['user']                  = 'Ditt MySQL-brukernavn';
$lang['password']              = 'Passord til brukeren';
$lang['database']              = 'Database som skal brukes';
$lang['debug_o_0']             = 'ingen';
$lang['debug_o_1']             = 'bare ved feil';
$lang['debug_o_2']             = 'alle SQL-forespørsler';
