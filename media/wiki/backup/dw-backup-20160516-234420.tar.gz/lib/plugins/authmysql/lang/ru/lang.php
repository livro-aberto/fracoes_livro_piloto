<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Takumo <9206984@mail.ru>
 */
$lang['connectfail']           = 'Ошибка соединения с базой данных.';
$lang['userexists']            = 'Извините, пользователь с таким логином уже существует.';
$lang['usernotexists']         = 'Извините, такой пользователь не существует.';
$lang['writefail']             = 'Невозможно изменить данные пользователя. Сообщите об этом администратору Вики.';
