<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author matej <mateju@svn.gnome.org>
 * @author Jernej Vidmar <jernej.vidmar@vidmarboehm.com>
 */
$lang['admin_password']        = 'Geslo zgoraj omenjenega uporabnika';
$lang['use_tls']               = 'Uporabi TLS povezavo? Če da, ne vključi SSL povezave zgoraj.';
$lang['debug']                 = 'Ali naj bodo prikazane dodatne podrobnosti napak?';
