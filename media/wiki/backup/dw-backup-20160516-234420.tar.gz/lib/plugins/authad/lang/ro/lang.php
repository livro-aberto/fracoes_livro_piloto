<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Razvan Deaconescu <razvan.deaconescu@cs.pub.ro>
 */
$lang['authpwdexpire']         = 'Parola va expira în %d zile, ar trebui să o schimbi în curând.';
