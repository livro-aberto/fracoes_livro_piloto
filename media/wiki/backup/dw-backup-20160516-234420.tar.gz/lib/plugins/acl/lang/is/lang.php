<?php
/**
 * Icelandic language file
 *
 * @author Hrannar Baldursson <hrannar.baldursson@gmail.com>
 * @author Ólafur Gunnlaugsson <oli@audiotools.com>
 * @author Erik Bjørn Pedersen <erik.pedersen@shaw.ca>
 */
$lang['acl_group']             = 'Hópur:';
$lang['acl_user']              = 'Notandi:';
$lang['page']                  = 'Síða';
$lang['namespace']             = 'Nafnrými';
$lang['btn_select']            = 'Veldu';
$lang['where']                 = 'Síða/Nafnrými';
$lang['acl_perm16']            = 'Eyða';
