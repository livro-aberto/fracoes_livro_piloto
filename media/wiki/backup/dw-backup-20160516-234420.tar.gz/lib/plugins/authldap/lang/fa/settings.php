<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Mohammad Sadegh <msdn2013@gmail.com>
 * @author Omid Hezaveh <hezpublic@gmail.com>
 */
$lang['starttls']              = 'از تی‌ال‌اس (TLS) استفاده می‌کنید؟';
$lang['bindpw']                = 'رمزعبور کاربر بالا';
