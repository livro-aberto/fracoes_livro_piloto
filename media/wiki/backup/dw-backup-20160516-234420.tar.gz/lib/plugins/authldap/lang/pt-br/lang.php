<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Frederico Gonçalves Guimarães <frederico@teia.bio.br>
 */
$lang['connectfail']           = 'Não foi possível conectar ao LDAP: %s';
$lang['domainfail']            = 'Não foi possível encontrar o seu user dn no LDAP';
