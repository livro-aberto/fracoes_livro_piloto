<?php
/**
 * English language file for authldap plugin
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 */

$lang['connectfail']     = 'LDAP cannot connect: %s';
$lang['domainfail']       = 'LDAP cannot find your user dn';

//Setup VIM: ex: et ts=4 :
