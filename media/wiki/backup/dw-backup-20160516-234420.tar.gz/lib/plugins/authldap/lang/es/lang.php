<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Mauricio Segura <maose38@yahoo.es>
 */
$lang['connectfail']           = 'LDAP no se puede conectar: %s';
