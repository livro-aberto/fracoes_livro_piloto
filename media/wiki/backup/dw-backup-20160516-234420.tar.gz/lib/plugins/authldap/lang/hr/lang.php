<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Davor Turkalj <turki.bsc@gmail.com>
 */
$lang['connectfail']           = 'LDAP se ne može spojiti: %s';
$lang['domainfail']            = 'LDAP ne može pronaći Vaš korisnički dn';
