<?php
/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 */
$lang['userexists']     = 'Təssüf ki bu ad ilə istifadəçi artıq mövcuddur.';
