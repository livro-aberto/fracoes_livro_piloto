<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author lainme <lainme993@gmail.com>
 */
$lang['userexists']            = '对不起，该用户名已经存在。';
$lang['usernotexists']         = '抱歉，该用户不存在';
$lang['writefail']             = '无法修改用户数据。请联系维基管理员';
