<?php
/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 */
$lang['userexists']     = 'نام کاربری‌ای که وارد کردید قبلن استفاده شده است. خواهشمندیم یک نام دیگر انتخاب کنید.';
