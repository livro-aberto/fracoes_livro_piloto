<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author RainbowSpike <1@2.ru>
 */
$lang['userexists']            = 'Извините, пользователь с таким логином уже существует.';
$lang['usernotexists']         = 'Этот пользователь незарегистрирован.';
$lang['writefail']             = 'Невозможно обновить данные пользователя. Свяжитесь с администратором вики';
