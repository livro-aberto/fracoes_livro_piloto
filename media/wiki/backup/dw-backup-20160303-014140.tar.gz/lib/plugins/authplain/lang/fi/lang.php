<?php
/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 */
$lang['userexists']     = 'Käyttäjä tällä käyttäjänimellä on jo olemassa.';
