<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Hideaki SAWADA <chuno@live.jp>
 */
$lang['userexists']            = 'このユーザー名は既に存在しています。';
$lang['usernotexists']         = 'このユーザーは未登録です。';
$lang['writefail']             = 'ユーザーデータを変更できません。管理者に問い合わせてください。';
