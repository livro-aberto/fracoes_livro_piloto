<?php
/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 */
$lang['userexists']     = 'দুঃখিত, এই লগইন সঙ্গে একটি ব্যবহারকারী ইতিমধ্যেই বিদ্যমান.';
