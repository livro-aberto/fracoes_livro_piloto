<?php
/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 */
$lang['userexists']     = 'Maaf, user dengan user login ini telah ada.';
