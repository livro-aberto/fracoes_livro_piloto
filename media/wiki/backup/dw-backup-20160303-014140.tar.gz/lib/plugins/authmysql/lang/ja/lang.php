<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Hideaki SAWADA <chuno@live.jp>
 */
$lang['connectfail']           = 'データベースへの接続に失敗しました。';
$lang['userexists']            = 'このログイン名のユーザーが既に存在しています。';
$lang['usernotexists']         = 'そのユーザーは存在しません。';
$lang['writefail']             = 'ユーザーデータを変更できません。Wiki の管理者に連絡してください。';
