<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Matej Urbančič <mateju@svn.gnome.org>
 */
$lang['database']              = 'Podatkovna zbirka za uporabo';
$lang['debug_o_0']             = 'brez';
$lang['debug_o_1']             = 'le ob napakah';
$lang['debug_o_2']             = 'vse poizvedbe SQL';
