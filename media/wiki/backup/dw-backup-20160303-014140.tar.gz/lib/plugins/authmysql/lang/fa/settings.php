<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Mohamad Mehdi Habibi <habibi.esf@gmail.com>
 */
$lang['server']                = 'سرور MySQL';
$lang['user']                  = 'نام کاربری MySQL';
$lang['database']              = 'پایگاه داده مورد استفاده';
