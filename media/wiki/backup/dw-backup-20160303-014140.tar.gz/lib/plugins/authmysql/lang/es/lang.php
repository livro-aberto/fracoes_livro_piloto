<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Domingo Redal <docxml@gmail.com>
 */
$lang['connectfail']           = 'Error al conectar con la base de datos.';
$lang['userexists']            = 'Lo sentimos, ya existe un usuario con ese inicio de sesión.';
$lang['usernotexists']         = 'Lo sentimos, no existe ese usuario.';
$lang['writefail']             = 'No es posible modificar los datos del usuario. Por favor, informa al Administrador del Wiki';
