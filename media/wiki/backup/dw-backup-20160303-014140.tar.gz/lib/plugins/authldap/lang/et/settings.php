<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Janar Leas <janar.leas@eesti.ee>
 */
$lang['grouptree']             = 'Kus kohast kasutaja rühmi otsida. Nt. <code>ou=Rühm, dc=server, dc=tld</code>';
$lang['groupscope']            = 'Piiritle otsingu ulatus rühma otsinguga';
