<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Takumo <9206984@mail.ru>
 */
$lang['connectfail']           = 'Ошибка соединения LDAP с %s';
$lang['domainfail']            = 'Не найдено имя пользователя LDAP (dn)';
