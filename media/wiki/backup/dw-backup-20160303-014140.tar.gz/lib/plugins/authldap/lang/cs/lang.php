<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Jaroslav Lichtblau <jlichtblau@seznam.cz>
 */
$lang['connectfail']           = 'LDAP připojení nefunkční: %s';
$lang['domainfail']            = 'LDAP nenalezlo uživatelské dn';
