<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Errol <errol@hotmail.com>
 */
$lang['connectfail']           = 'LDAP 无法连接: %s';
$lang['domainfail']            = 'LDAP 无法找到你的用户 dn';
