<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author chris taklis <ctaklis@gmail.com>
 */
$lang['admin_password']        = 'Ο κωδικός του παραπάνω χρήστη.';
