<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Mohamed Belhsine <b.mohamed897@gmail.com>
 * @author Usama Akkad <uahello@gmail.com>
 */
$lang['domain']                = 'مجال تسجيل الدخول';
$lang['authpwdexpire']         = 'ستنتهي صلاحية كلمة السر في %d . عليك بتغييرها سريعا.';
