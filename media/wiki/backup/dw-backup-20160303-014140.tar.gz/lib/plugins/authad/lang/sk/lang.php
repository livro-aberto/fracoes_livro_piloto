<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Martin Michalek <michalek.dev@gmail.com>
 */
$lang['authpwdexpire']         = 'Platnosť hesla vyprší za %d dní, mali by ste ho zmeniť čo najskôr.';
