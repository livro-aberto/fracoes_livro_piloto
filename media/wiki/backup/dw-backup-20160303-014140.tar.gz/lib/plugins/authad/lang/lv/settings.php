<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Aivars Miška <allefm@gmail.com>
 */
$lang['account_suffix']        = 'Jūsu konta sufikss. Piemēram, <code>@my.domain.org</code>';
$lang['domain_controllers']    = 'Ar komatiem atdalīts domēna kontroleru saraksts. Piemēram, <code>srv1.domain.org,srv2.domain.org</code>';
$lang['admin_password']        = 'Minētā lietotāja parole.';
$lang['expirywarn']            = 'Cik dienas iepriekš brīdināt lietotāju par paroles termiņa beigām. Ierakstīt 0, lai atspējotu.';
