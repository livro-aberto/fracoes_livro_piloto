<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Hamid <zarrabi@sharif.edu>
 * @author Milad DZand <M.DastanZand@gmail.com>
 */
$lang['domain']                = 'دامنه‌ی ورود';
$lang['authpwdexpire']         = 'کلمه عبور شما در %d روز منقضی خواهد شد ، شما باید آن را زود تغییر دهید';
