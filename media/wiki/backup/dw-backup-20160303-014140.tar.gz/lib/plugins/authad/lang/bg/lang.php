<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Kiril <neohidra@gmail.com>
 */
$lang['authpwdexpire']         = 'Срока на паролата ви ще изтече след %d дни. Препоръчително е да я смените по-скоро.';
