<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Aleksandr Selivanov <alexgearbox@yandex.ru>
 * @author Takumo <9206984@mail.ru>
 */
$lang['domain']                = 'Домен';
$lang['authpwdexpire']         = 'Действие вашего пароля истекает через %d дней. Вы должны изменить его как можно скорее';
$lang['passchangefail']        = 'Не удалось изменить пароль. Возможно, он не соответствует требованиям к паролю.';
$lang['connectfail']           = 'Невозможно соединиться с сервером AD.';
