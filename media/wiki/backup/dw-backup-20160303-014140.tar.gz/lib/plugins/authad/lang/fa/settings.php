<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Omid Hezaveh <hezpublic@gmail.com>
 */
$lang['admin_password']        = 'رمز کاربر بالایی ';
$lang['use_ssl']               = 'از اس‌اس‌ال استفاده می‌کنید؟ در این صورت تی‌ال‌اس را در پایین فعال نکنید. ';
$lang['use_tls']               = 'از تی‌ال‌اس استفاده می‌کنید؟ در این صورت اس‌اس‌ال را در بالا فعال نکنید. ';
