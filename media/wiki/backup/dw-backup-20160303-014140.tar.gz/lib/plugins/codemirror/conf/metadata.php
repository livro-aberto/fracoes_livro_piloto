<?php

require_once(DOKU_INC.'lib/plugins/codemirror/action.php');

$meta['nativeeditor'] = array('onoff');
$meta['codesyntax'] = array('onoff');
