<?php

$conf['nativeeditor'] = '0';
$conf['codesyntax'] = '0';
