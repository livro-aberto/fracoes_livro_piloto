<?php
 
/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 */
$lang['js']['setting_activeline'] = '現在行の強調表示';
$lang['js']['setting_closebrackets'] = '閉じ括弧の自動入力';
$lang['js']['setting_fontsize'] = 'フォントサイズ';
$lang['js']['setting_keymap'] = 'キーボードマッピング';
$lang['js']['setting_linenumbers'] = '行番号表示';
$lang['js']['setting_matchbrackets'] = '対応する括弧の強調表示';
$lang['js']['setting_syntax'] = '構文の強調表示';
$lang['js']['setting_theme'] = 'カラーテーマ';
