<?php

$lang['nativeeditor'] = 'Use native DokuWiki editor as default.';
$lang['codesyntax'] = 'Use CodeMirror to highlight syntax of code blocks when viewing pages.';
