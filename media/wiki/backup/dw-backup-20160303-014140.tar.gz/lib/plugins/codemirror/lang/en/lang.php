<?php

$lang['js']['setting_activeline'] = 'Highlight current line';
$lang['js']['setting_closebrackets'] = 'Auto-close brackets';
$lang['js']['setting_fontsize'] = 'Font size';
$lang['js']['setting_keymap'] = 'Key map';
$lang['js']['setting_linenumbers'] = 'Display line numbers';
$lang['js']['setting_matchbrackets'] = 'Highlight matching brackets';
$lang['js']['setting_nativeeditor'] = 'Native DokuWiki editor';
$lang['js']['setting_syntax'] = 'Highlight syntax';
$lang['js']['setting_theme'] = 'Color theme';
