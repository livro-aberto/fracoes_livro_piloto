<?php

$lang['nativeeditor'] = 'Utilitza l\'editor natiu de DokuWiki per defecte';
$lang['codesyntax'] = 'Utilitza el CodeMirror per ressaltar la sintaxi dels blocs de codi en visualitzar les pàgines.';
