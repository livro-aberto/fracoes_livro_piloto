<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Hideaki SAWADA <chuno@live.jp>
 */
$lang['nativeeditor']          = 'DokuWiki 編集画面をデフォルトで使う';
