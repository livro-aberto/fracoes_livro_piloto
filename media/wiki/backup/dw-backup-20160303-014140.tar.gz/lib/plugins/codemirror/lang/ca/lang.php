<?php

$lang['js']['setting_activeline'] = 'Ressalta la línia actual';
$lang['js']['setting_closebrackets'] = 'Tanca els parèntesis automàticament';
$lang['js']['setting_fontsize'] = 'Mida de la lletra';
$lang['js']['setting_keymap'] = 'Mapa de tecles';
$lang['js']['setting_linenumbers'] = 'Mostra els números de línia';
$lang['js']['setting_matchbrackets'] = 'Ressalta els parèntesis concordants';
$lang['js']['setting_nativeeditor'] = 'Editor natiu de DokuWiki';
$lang['js']['setting_syntax'] = 'Ressalta la sintaxi';
$lang['js']['setting_theme'] = 'Tema de colors';
