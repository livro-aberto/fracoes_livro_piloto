<?php

$lang['js']['setting_activeline'] = 'Aktuelle Zeile hervorheben';
$lang['js']['setting_closebrackets'] = 'Klammern automatisch schließen';
$lang['js']['setting_fontsize'] = 'Font Größe';
$lang['js']['setting_keymap'] = 'Tastenzuordnung';
$lang['js']['setting_linenumbers'] = 'Zeige Zeilennummern';
$lang['js']['setting_matchbrackets'] = 'passende Klammern hervorheben';
$lang['js']['setting_syntax'] = 'Syntax hervorheben';
$lang['js']['setting_theme'] = 'Farbschema';
