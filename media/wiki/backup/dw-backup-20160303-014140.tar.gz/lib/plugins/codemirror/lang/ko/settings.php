<?php

$lang['nativeeditor'] = '네이티브 도쿠위키 편집기를 기본값으로 사용';
