<?php

$lang['js']['setting_activeline'] = '현재 줄 강조';
$lang['js']['setting_closebrackets'] = '괄호 자동 닫기';
$lang['js']['setting_fontsize'] = '글꼴 크기';
$lang['js']['setting_keymap'] = '키보드 매핑';
$lang['js']['setting_linenumbers'] = '줄 번호 보이기';
$lang['js']['setting_matchbrackets'] = '일치하는 괄호 강조';
$lang['js']['setting_nativeeditor'] = '네이티브 도쿠위키 편집기';
$lang['js']['setting_syntax'] = '구문 강조';
$lang['js']['setting_theme'] = '색상 테마';
