<?php

$lang['nativeeditor'] = 'Nativen DokuWiki Editor als Standard verwenden';
