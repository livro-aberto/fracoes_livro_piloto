<?php

$lang['js']['setting_activeline'] = 'Подсветка текущей строки';
$lang['js']['setting_closebrackets'] = 'Автозакрытие скобок';
$lang['js']['setting_fontsize'] = 'Размер шрифта';
$lang['js']['setting_keymap'] = 'Раскладка';
$lang['js']['setting_linenumbers'] = 'Отображать номера строк';
$lang['js']['setting_matchbrackets'] = 'Подсветка парных скобок';
$lang['js']['setting_nativeeditor'] = 'Родной редактор DokuWiki';
$lang['js']['setting_syntax'] = 'Подсветка синтаксиса';
$lang['js']['setting_theme'] = 'Цветовая схема';
