<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Fabrice Dejaigher <fabrice@chtiland.com>
 */
$lang['nativeeditor']          = 'Utiliser l\'éditeur natif de Dokuwiki par défaut';
