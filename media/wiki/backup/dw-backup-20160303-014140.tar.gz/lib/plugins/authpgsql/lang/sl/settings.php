<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Matej Urbančič <mateju@svn.gnome.org>
 * @author matej <mateju@svn.gnome.org>
 */
$lang['database']              = 'Podatkovna zbirka za uporabo';
$lang['addUserGroup']          = 'Ukaz SQL za dodajanje uporabnika v obstoječo skupino';
$lang['delGroup']              = 'Ukaz SQL za odstranitev skupine';
$lang['getUserID']             = 'Ukaz SQL za pridobitev osnovnega ključa uporabnika';
$lang['delUser']               = 'Ukaz SQL za izbris uporabnika';
$lang['delUserRefs']           = 'Ukaz SQL za odstranitev uporabnika iz vseh skupin';
$lang['updateUser']            = 'Ukaz SQL za posodobitev profila uporabnika';
$lang['delUserGroup']          = 'Ukaz SQL za odstranitev uporabnika iz podane skupine';
$lang['getGroupID']            = 'Ukaz SQL za pridobitev osnovnega ključa podane skupine';
