<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Kiril <neohidra@gmail.com>
 */
$lang['server']                = 'Вашият PostgreSQL сървър';
$lang['port']                  = 'Порт за PostgreSQL сървъра';
$lang['user']                  = 'PostgreSQL потребител';
$lang['password']              = 'Парола за горния потребител';
$lang['database']              = 'Име на базата от данни';
$lang['debug']                 = 'Показване на допълнителна debug информация';
