<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Mohamad Mehdi Habibi <habibi.esf@gmail.com>
 */
$lang['database']              = 'پایگاه داده مورد استفاده';
