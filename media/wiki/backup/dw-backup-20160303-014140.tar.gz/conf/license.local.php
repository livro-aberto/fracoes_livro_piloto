<?php
$license['tdr'] = array(
    'name' => 'Todos os direitos reservados',
    'url'  => 'http://www.google.com',
);
