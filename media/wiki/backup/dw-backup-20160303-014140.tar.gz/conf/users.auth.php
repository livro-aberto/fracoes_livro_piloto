admin:d7204f06b530649b34021933c2ed938a:DokuWiki Administrator:webmaster@localhost:admin,user
simas:$1$YX7vVUlu$z2gzt6oEDAjG5Xfdg0ig4/:Fabio Simas:fabio.simas@uniriotec.br:coordenadores
hjbortol:$1$He95j6wo$JEfTiCDPXBME.cBgslsoE0:Humberto Bortolossi:hjbortol@gmail.com:coordenadores
leticiarangel:$1$HSNbugCq$NmbnzaXnWesp5CVEkScKh/:Leticia Rangel:leticiagrangel@gmail.com:coordenadores
victor:$1$Qodc9YVo$JbKLzbYksJedYhDLeOOKw/:Victor Giraldo:victor.giraldo@gmail.com:coordenadores
anapaula:$1$hOHnjdyQ$gVMckQrcErX/B2FJZTzfj/:Ana Paula:anaperei@hotmail.com:coordenadores
luizfelipe:$1$w0OXMTkF$bd8mJT3hSFAhp1qYlOnjQ1:Luiz Felipe:lfelipel@terra.com.br:coordenadores
francisco:$1$XmfMUZ7w$zCzYHdef4jXHeHbJt8FpL0:Francisco Mattos:francisco.mattos@gmail.com:coordenadores
